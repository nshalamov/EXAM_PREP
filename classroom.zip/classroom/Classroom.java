package classroom;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Classroom {
    public int capacity;
    public List<Student> students;

    public Classroom(int capacity) {
        this.capacity = capacity;
        this.students = new ArrayList<>();
    }

    public int getCapacity() {
        return this.capacity;
    }

    public List<Student> getStudents() {
        return this.students;
    }

    public int getStudentCount() {
        return this.students.size();
    }

    public String registerStudent(Student student) {
        if (this.students.size() < capacity) {
            if (!this.students.contains(student)) {
                this.students.add(student);
                return ("Added student "
                        + student.getFirstName() + " " + student.getLastName());
            } else {
                return ("Student is already in the classroom");
            }
        } else {
            return ("No seats in the classroom");
        }
    }

    public String dismissStudent(Student student) {
        if (this.students.contains(student)) {
            this.students.remove(student);
            return ("Removed student "
                    + student.getFirstName() + " " + student.getLastName());
        } else {
            return ("Student not found");
        }
    }

    public String getSubjectInfo(String subject) {
        StringBuilder sb = new StringBuilder();

        List<Student> neededStudents = this.students
                .stream()
                .filter(s -> s.getBestSubject().equals(subject))
                .collect(Collectors.toList());
        if (neededStudents.size() > 0) {
            sb.append("Subject: ")
                    .append(subject)
                    .append(System.lineSeparator())
                    .append("Students:")
                    .append(System.lineSeparator());
            for (int i = 0; i < neededStudents.size(); i++) {
                if (i < neededStudents.size() - 1) {
                    sb.append(neededStudents.get(i).getFirstName())
                            .append(" ")
                            .append(neededStudents.get(i).getLastName())
                    .append(System.lineSeparator());
                } else {
                    sb.append(neededStudents.get(i).getFirstName())
                            .append(" ")
                            .append(neededStudents.get(i).getLastName());
                }
            }
            return sb.toString().trim();

        } else {
            return "No students enrolled for the subject";
        }
    }

    public Student getStudent(String firstName, String lastName) {
        for (Student student : students) {
            if (student.getFirstName().equals(firstName) &&
                    student.getLastName().equals(lastName)) {
                return student;
            }
        }
        return null;
    }

    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        sb.append("Classroom size: ")
                .append(this.students.size())
                .append(System.lineSeparator());
        for (int i = 0; i < this.students.size(); i++) {
            if (i < this.students.size() - 1) {
                sb.append("==Student: First Name= ")
                        .append(students.get(i).getFirstName())
                        .append(", Last Name= ")
                        .append(students.get(i).getLastName())
                        .append(", Best Subject= ")
                        .append(students.get(i).getBestSubject())
                        .append(System.lineSeparator());
            } else {
                sb.append("==Student: First Name= ")
                        .append(students.get(i).getFirstName())
                        .append(", Last Name= ")
                        .append(students.get(i).getLastName())
                        .append(", Best Subject= ")
                        .append(students.get(i).getBestSubject());
            }
        }

        return sb.toString().trim();
    }
}